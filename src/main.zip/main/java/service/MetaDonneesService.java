package service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import model.MetaDonnees;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MetaDonneesService {
    // Chemin de sauvegarde
    private static final String FILE_PATH = "metadonnees.json";
    private static final Gson gson = new Gson();

    // Méthode pour lire les fichiers et convertir le JSON en une liste d'objets MetaDonnees
    public static List<MetaDonnees> charge() {
        File file = new File(FILE_PATH);

        // Si le fichier n'existe pas, créer un fichier vide
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return new ArrayList<>(); // Si le fichier est vide ou inexistant, retourner une liste vide
        }

        // Lire le fichier JSON et le convertir en liste d'objets
        try (FileReader reader = new FileReader(file)) {
            Type listType = new TypeToken<ArrayList<MetaDonnees>>(){}.getType();
            return gson.fromJson(reader, listType);

        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>(); // En cas d'erreur, retourner une liste vide
        }
    }

    // Sauvegarde la liste de MetaDonnees dans le fichier JSON
    public static void sauvegarde(List<MetaDonnees> liste) {
        try (FileWriter writer = new FileWriter(FILE_PATH)) {
            gson.toJson(liste, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Ajoute une nouvelle MetaDonnees (en enlevant une image déjà présente)
    public static void ajouter(MetaDonnees nouvelle) {
        List<MetaDonnees> liste = charge();

        // Retirer l'ancienne entrée si le chemin est le même
        liste.removeIf(m -> m.getChemin().equals(nouvelle.getChemin()));

        // Ajouter la nouvelle entrée
        liste.add(nouvelle);

        // Sauvegarder les modifications
        sauvegarde(liste);
    }

    // Trouver une MetaDonnees à partir de son chemin
    public static MetaDonnees trouver(String chemin) {
        return charge().stream()
                .filter(m -> m.getChemin().equals(chemin))
                .findFirst()
                .orElse(null);
    }
}
