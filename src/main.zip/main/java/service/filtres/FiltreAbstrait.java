package service.filtres;

import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.image.Image;

public abstract class FiltreAbstrait implements Filtre {
    protected int width,height;
    protected PixelReader reader;
    protected PixelWriter writer;
    protected WritableImage wImage;

    protected void initialise(Image inputImage){
        width =(int) inputImage.getWidth();
        height =(int) inputImage.getHeight();
        reader=inputImage.getPixelReader();
        wImage=new WritableImage(width,height);
        writer=wImage.getPixelWriter();
    }

}
