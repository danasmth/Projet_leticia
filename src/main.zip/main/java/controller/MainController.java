package controller;





 import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
 import model.MetaDonnees;
 import model.Transformation;
 import service.MetaDonneesService;
 import service.Rotate;
import service.filtres.Filtre;
import java.io.File;

 import service.filtres.ClassFiltres;

public class MainController {
    @FXML
    private ImageView imageView;

    private File currentImageFile;

    @FXML
    protected void handleChooseImage() {


        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("choisir une image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Images", "*.jpg", "*.png", "*.gif")
        );
       File file = fileChooser.showOpenDialog(null);
       if(file != null) {
           currentImageFile = file;
           Image image = Rotate.loadImageFromFile(file);
           // appeler la methode de rotation dnas la classe service
           Image rotated = Rotate.rotation(image);
           imageView.setImage(image);
           String chemin = file.getAbsolutePath();
           //creer un objet Metadonnees pour cette image
           MetaDonnees meta = new MetaDonnees(chemin);

           //ajouter un tag
           meta.ajouterTag("choisi");

           // les ajouter a la sauvegarde
           MetaDonneesService.ajouter(meta);

       }

        }
    @FXML
     protected void handleGreyFilter() {
        if(imageView.getImage() != null){
              Filtre img= new ClassFiltres();
              Image grey=img.NoirEtBlanc(imageView.getImage());
              imageView.setImage(grey);

              //recuperer les metadonnées
            String chemin=currentImageFile.getAbsolutePath();
            MetaDonnees meta=new MetaDonneesService().trouver(chemin);

            if(meta == null){
                meta=new MetaDonnees(chemin);
            }
            meta.ajouterTransformation(new Transformation("noir et blanc","fort"));
            //sauvegarder
            MetaDonneesService.ajouter(meta);
          }
    }

    @FXML
    protected void handleSepiaFilter() {
        if(imageView.getImage() != null){
            Filtre img= new ClassFiltres();
            Image sepia=img.sepia(imageView.getImage());
            imageView.setImage(sepia);
            //recuperer les metadonnées
            String chemin=currentImageFile.getAbsolutePath();
            MetaDonnees meta=new MetaDonneesService().trouver(chemin);

            if(meta == null){
                meta=new MetaDonnees(chemin);
            }
            meta.ajouterTransformation(new Transformation("SEPIA","fort"));
            //sauvegarder
            MetaDonneesService.ajouter(meta);
        }
    }
    @FXML
    protected void handleSwapFilter() {
        if(imageView.getImage() != null){
          Filtre img= new ClassFiltres();
          Image swap=img.swapComposantes(imageView.getImage());
          imageView.setImage(swap);

            //recuperer les metadonnées
            String chemin= currentImageFile.getAbsolutePath();
            MetaDonnees meta=new MetaDonneesService().trouver(chemin);

            if(meta == null){
                meta=new MetaDonnees(chemin);
            }
            meta.ajouterTransformation(new Transformation("swap","fort"));
            //sauvegarder
            MetaDonneesService.ajouter(meta);
        }

    }
    @FXML
    protected void handleSobelFilter() {
        if(imageView.getImage() != null){
            Filtre img= new ClassFiltres();
            Image sobel=img.sobel(imageView.getImage());
            imageView.setImage(sobel);

            //recuperer les metadonnées
            String chemin= currentImageFile.getAbsolutePath();
            MetaDonnees meta=new MetaDonneesService().trouver(chemin);

            if(meta == null){
                meta=new MetaDonnees(chemin);
            }
            meta.ajouterTransformation(new Transformation("sobel","fort"));
            //sauvegarder
            MetaDonneesService.ajouter(meta);
        }
    }

    }
